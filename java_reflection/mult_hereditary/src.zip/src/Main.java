import java.lang.reflect.Proxy;

public class Main {
    public static void main(String[] args) {
        IParent target = (IParent) Proxy.newProxyInstance(
                Main.class.getClassLoader(),
                new Class[]{IParent.class},
                new MyHandler(IParent1.class, IParent2.class)
        );

        target.methdodParent1();
        target.methodParent1(1);
        target.methdodParent2();
        target.methodParent1("ciao");
        target.methodParent1("ciao", "ciao");
    }
}
