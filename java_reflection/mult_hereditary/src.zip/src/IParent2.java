public interface IParent2 {
    void methdodParent2();
    void methodParent1(String x);
    void methodParent1(String x, String y);
}
