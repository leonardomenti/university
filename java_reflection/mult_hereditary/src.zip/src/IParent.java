public interface IParent extends IParent1, IParent2{
}
