public class Parent1 implements IParent1{
    public void methdodParent1() {
        System.out.println("Method of parent 1");
    }

    public void methodParent1(int a) {
        System.out.println("Method of parent 1 with int");
    }
}
