public interface IParent1 {
    void methdodParent1();
    void methodParent1(int a);
}
